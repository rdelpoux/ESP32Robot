#ifndef ROBOTNUMBER_H_
#define ROBOTNUMBER_H_

#define ROBOTNUMBER 101 // 100+robotnumber

#endif /* ROBOTNUMBER_H_ */
