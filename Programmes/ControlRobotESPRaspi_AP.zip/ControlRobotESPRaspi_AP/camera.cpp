/*
 * moteur.hpp
*
 *  Created on: 15 Mai 2023
 *   Last Modification: 15 Mai 2023
 *      Author: Romain Delpoux (romain.delpoux@insa-lyon.fr)
 */
  
#include <Arduino.h>

#include "camera.hpp"
#include "types.h"

Camera::Camera() {

	
  	this->pin_RX = 0;
  	this->pin_TX = 0;
  	this->pos = 0;
  	this->pos_old = 0;
	this->state = STATE_INIT;

}

Camera::Camera(int pin_RX, int pin_TX) {

	this->config(pin_RX, pin_TX);
}


Camera::~Camera() {

}

void Camera::config(int pin_RX, int pin_TX) {

	this->pin_RX = pin_RX;
	this->pin_TX = pin_TX;

	/* Set Serial Com pins */
  	Serial2.begin(57600, SERIAL_8N1, pin_RX, pin_TX);
  	Serial.println("Serial Txd Cam is on pin: " + String(TX));
  	Serial.println("Serial Rxd Cam on pin: " + String(RX));

	
	/* Motor OK */
	this->state = STATE_OK;

}

void Camera::run() {

	if (this->state == STATE_OK || this->state == STATE_STOP) {
		this->state = STATE_RUN;
	}
}

void Camera::stop() {
	this->state = STATE_STOP;
}

float Camera::get_angle() {

    cpt = 0;

    if (Serial2.available()) {
      byt = Serial2.read();
      if (byt == '>') {
        while (cpt < 3) {
          if (Serial2.available()) {
            Message[cpt] = Serial2.read();
            cpt++;
          }
        }

        memcpy(&data, Message + 1, 2);
      }
      if(Message[0] == 0) {
          pos_old =  pos ;
          pos = ((int) data)/320.0-1;
        if ( pos == -1 && pos_old > 0 ){
          pos = 1 ; 
        } 
      }

    }
   Serial.print("Pos = ");
      Serial.print("\t");
      Serial.print(pos);
      Serial.print("\t");
      Serial.println(pos_old);

	return pos;


}
