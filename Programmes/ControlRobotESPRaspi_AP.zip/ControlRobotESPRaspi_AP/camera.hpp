/*
 * moteur.hpp
*
 *  Created on: 15 Mai 2023
 *   Last Modification: 15 Mai 2023
 *      Author: Romain Delpoux (romain.delpoux@insa-lyon.fr)
 */
 
#ifndef CAMERA_HPP_
#define CAMERA_HPP_

class Camera {
private:
	/* State */
	int state;
	
	char byt;
	char Message[5];
	int data;
	int cpt;
	float pos;
	float pos_old; 

  int pin_RX;
  int pin_TX;

public:
	Camera();
	Camera(int pin_RX, int pin_TX);
	~Camera();

	void config(int pin_RX, int pin_TX);

	void run();
	void stop();


	float get_angle();


};


#endif /* CAMERA_HPP_ */
