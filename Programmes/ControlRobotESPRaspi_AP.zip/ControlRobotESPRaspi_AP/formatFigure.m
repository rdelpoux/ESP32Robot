function formatFigure
% formatFigure : affine l'affichage de la figure courante : 
%	- texte en latex (usage de formule dans $$ possible)
%	- epaisseur du trait de 1.2
%	- encadrement
% 
% Signature : formatFigure
% 
% Exemple :
%   formatFigure;
%
% Auteur : JFT

fs = 15;% font-size

set(gca,'fontsize',fs);

% changement de l'epaisseur du trait pour toutes les sous-figures (y
% compris les legendes), si l'épaisseur est celle par défaut
hline = findobj(gcf, 'Type', 'line');
if (length(hline)>1)
    tablw = cell2mat(get(hline,'LineWidth'));
else
    tablw = get(hline,'LineWidth');
end
ind = (tablw==get(gca,'defaultLineLineWidth'));
set(hline(ind),'LineWidth',1.2);

txt = findall(gcf,'Type','text'); % findall commme findobj mais renvoie aussi les objects cachés (ceux des sous-figures ?)
for ii = 1:length(txt)
    setLatexModeXYLabel(txt(ii),fs);
end

leg = findall(gcf,'Type','legend');
for ii = 1:length(leg)
    set(leg(ii),'Interpreter','Latex');
end

leg = findall(gcf,'Type','axes');
for ii = 1:length(leg)
    set(leg(ii),'box','on');
    grid(leg(ii),'on');
end

t = get(gcf,'Children'); % tableau des sous-figures
for ii = 1:length(t)
    set(t(ii),'FontSize',fs-4);
end

% ANCIENNE VERSION
% for ii = 1:length(t)
%     pId = t(ii);
%     set(pId,'FontSize',fs);
%     if strcmpi(get(pId,'Tag'),'legend')
%         % c'est une legende
%         set(pId,'Interpreter','Latex');
%     else
%         % c'est un subplot
%         set(pId,'box','on');
%         grid(pId,'on');
%     end
% end

end

function setLatexModeXYLabel(id,fs)

ancienText = get(id,'String');
if ~isempty(ancienText)
%     disp([get(id,'Type'),'/',get(id,'Tag')]);
%     if strcmpi(get(pId,'Tag'),'')
%         set(id,'String',strrep(ancienText, '$', '$$')); % redoublement des $
%     end
    set(id,'Interpreter','Latex');
    set(id,'FontSize',fs);
end

end
