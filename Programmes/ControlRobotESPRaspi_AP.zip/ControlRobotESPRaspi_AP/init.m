K= 15.532 ; %17.6/3 ; 
T = 0.15 ; % 0.11 ; 
r= 60e-3 ;  % m wheel diameter 
d =0.18 ;   % m distance between two wheels

%% correcteur de  position  PD 
% cahier des charges 
tr_5 =3*T ; %% on garde la meme dynamique pour le PD 
%%%% lorsque on prend une vitesse moyenne grande il faut acceler la boucle
%%%% de position. Lorsque la vitesse moyen et grande il faut rejeter les
%%%% perturbation plus rapidement (le suivit de trajectoire est un probleme de regulation)
w_0 = 3/tr_5 ; 
xi_0 = 1 ; 
% modele : 1/s K_n/(T_n s+1)
K_n = K*r/d ; 
T_n = T ; 
%controle  PD 
Kp_pos = T_n*w_0^2/K_n  ;  
Kd_pos =  K_n*Kp_pos*2*xi_0/w_0-1 ; 
N= 2;  

%% commentaire :  test expé effectué 
% le PI est codé en hard dans le simulink 
% il y a une perturbation dand l'integrateur pour simuler un virage

%%%%%%test 1
%%%  je garde la meme dynamique : tr_5 =3*T 
%%% Kd_pos = 0.4, Kp_pos= 1.28 , vmoy_ref = 0.5 m/s
%%%%

%%%%%%test 2
%%%  j'accelère la dynamique de rejet de perturbation : tr_5 =1.5*T 
%%% Kd_pos = 1.8, Kp_pos= 5.15 , vmoy = 1 m/s
%%% Ok, fonctionne, mais pas beaucoup de point 
%%%%

%%%%%%test 3
%%%  j'accelère  encore plus la dynamique de rejet de perturbation : tr_5 =1*T 
%%% Kd_pos = 1.8, Kp_pos= 5.15 , vmoy = 1 m/s
%%% Ok, fonctionne, mais  vraiment pas beaucoup de point très proche de T_echantillonnage 
%%%%

%%%%%%test 4
%%%  j'accelère la dynamique de rejet de perturbation : tr_5 =1.5*T et x= 1
%%% Kd_pos = 3, Kp_pos= 5.15 , vmoy = 1 m/s
%%% Ok, fonctionne, mais pas beaucoup de point + plus de derivé --> moins d'oscillation 
%%%%

%%%% remarque genrale
% - c'est un problème plus de regulation que d'asservissement 
% - perturbation presente tout le temps a cause du trajet 
% -probleme de regulation intéréssant pour a regarder en terme de fonction
% de sensibilité ! il faut faire attention a ce que la dynamique de rejet
% de perturbation soit plus rapide que celle de l'asservissement de vitesse
% moyenne 
% - Mettre antiwind-up (leur parler du problème d'emballement d'intégrateur en TP ? )
%%%%
